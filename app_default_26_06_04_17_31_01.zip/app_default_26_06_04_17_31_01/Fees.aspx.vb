Imports System.Data
Imports System.Data.SqlClient

Partial Class Fees
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadData()
        End If
    End Sub

    Private Sub LoadData()
        ddlStudent.DataSource = DBHelper.GetDataTable("SELECT StudentID, FullName FROM Students")
        ddlStudent.DataBind()

        ddlFeeStatus.DataSource = DBHelper.GetDataTable("SELECT * FROM FeesStatus")
        ddlFeeStatus.DataBind()

        gvFees.DataSource = DBHelper.GetDataTable("SELECT f.*, s.FullName, fs.StatusName FROM Fees f JOIN Students s ON f.StudentID = s.StudentID JOIN FeesStatus fs ON f.FeesStatusID = fs.FeesStatusID ORDER BY PaymentDate DESC")
        gvFees.DataBind()
    End Sub

    Protected Sub btnPay_Click(sender As Object, e As EventArgs)
        Dim sql As String = "INSERT INTO Fees (StudentID, AmountPaid, PaymentDate, FeesStatusID) VALUES (@sid, @amt, GETDATE(), @stat)"
        Dim params As SqlParameter() = {
            New SqlParameter("@sid", ddlStudent.SelectedValue),
            New SqlParameter("@amt", txtAmount.Text),
            New SqlParameter("@stat", ddlFeeStatus.SelectedValue)
        }
        DBHelper.ExecuteProcedure("sp_executesql", {New SqlParameter("@statement", sql), params(0), params(1), params(2)})
        txtAmount.Text = ""
        LoadData()
    End Sub
End Class
