<%@ Page Title="Results" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Results.aspx.vb" Inherits="Results" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Examination Results</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label>Student</label>
                    <asp:DropDownList ID="ddlResStudent" runat="server" CssClass="form-select" DataTextField="FullName" DataValueField="StudentID"></asp:DropDownList>
                </div>
                <div class="col-md-2">
                    <label>Subject</label>
                    <asp:TextBox ID="txtSubject" runat="server" CssClass="form-control"></asp:TextBox>
                </div>
                <div class="col-md-2">
                    <label>Marks</label>
                    <asp:TextBox ID="txtMarks" runat="server" CssClass="form-control" TextMode="Number"></asp:TextBox>
                </div>
                <div class="col-md-2">
                    <label>Total</label>
                    <asp:TextBox ID="txtTotal" runat="server" CssClass="form-control" TextMode="Number" Text="100"></asp:TextBox>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <asp:Button ID="btnAddResult" runat="server" Text="Add Result" CssClass="btn btn-primary w-100" OnClick="btnAddResult_Click" />
                </div>
            </div>
        </div>
    </div>
    <asp:GridView ID="gvResults" runat="server" CssClass="table table-striped table-bordered" AutoGenerateColumns="true">
        <HeaderStyle CssClass="table-dark" />
    </asp:GridView>
</asp:Content>
