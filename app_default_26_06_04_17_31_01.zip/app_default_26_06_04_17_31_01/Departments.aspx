<%@ Page Title="Departments" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Departments.aspx.vb" Inherits="Departments" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Departments</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="card shadow-sm w-50 mb-4">
        <div class="card-body">
            <div class="input-group">
                <asp:TextBox ID="txtDeptName" runat="server" CssClass="form-control" placeholder="Department Name"></asp:TextBox>
                <asp:Button ID="btnAddDept" runat="server" Text="Add Department" CssClass="btn btn-primary" OnClick="btnAddDept_Click" />
            </div>
        </div>
    </div>
    <asp:GridView ID="gvDepts" runat="server" CssClass="table table-bordered w-50" AutoGenerateColumns="true"></asp:GridView>
</asp:Content>
