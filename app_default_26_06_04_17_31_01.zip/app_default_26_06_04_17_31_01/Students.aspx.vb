Imports System.Data
Imports System.Data.SqlClient

Partial Class Students
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadLookups()
            BindGrid()
        End If
    End Sub

    Private Sub LoadLookups()
        ddlGender.DataSource = DBHelper.GetDataTable("SELECT * FROM Genders")
        ddlGender.DataBind()

        ddlCategory.DataSource = DBHelper.GetDataTable("SELECT * FROM StudentCategory")
        ddlCategory.DataBind()

        ddlCourse.DataSource = DBHelper.GetDataTable("SELECT * FROM Courses")
        ddlCourse.DataBind()

        ddlSemester.DataSource = DBHelper.GetDataTable("SELECT * FROM Semesters")
        ddlSemester.DataBind()

        ddlCity.DataSource = DBHelper.GetDataTable("SELECT * FROM Cities")
        ddlCity.DataBind()

        ddlState.DataSource = DBHelper.GetDataTable("SELECT * FROM States")
        ddlState.DataBind()
    End Sub

    Private Sub BindGrid()
        gvStudents.DataSource = DBHelper.GetDataTableFromProc("sp_GetStudents")
        gvStudents.DataBind()
    End Sub

    Protected Sub btnSave_Click(sender As Object, e As EventArgs)
        Dim sqlParams As SqlParameter() = {
            New SqlParameter("@StudentID", If(hdnStudentID.Value = "0", DBNull.Value, hdnStudentID.Value)),
            New SqlParameter("@FullName", txtFullName.Text),
            New SqlParameter("@DOB", If(String.IsNullOrEmpty(txtDOB.Text), DBNull.Value, txtDOB.Text)),
            New SqlParameter("@GenderID", ddlGender.SelectedValue),
            New SqlParameter("@CategoryID", ddlCategory.SelectedValue),
            New SqlParameter("@Email", txtEmail.Text),
            New SqlParameter("@Phone", txtPhone.Text),
            New SqlParameter("@Address", txtAddress.Text),
            New SqlParameter("@CityID", ddlCity.SelectedValue),
            New SqlParameter("@StateID", ddlState.SelectedValue),
            New SqlParameter("@CourseID", ddlCourse.SelectedValue),
            New SqlParameter("@SemesterID", ddlSemester.SelectedValue)
        }
        DBHelper.ExecuteProcedure("sp_UpsertStudent", sqlParams)
        btnClear_Click(Nothing, Nothing)
        BindGrid()
    End Sub

    Protected Sub btnClear_Click(sender As Object, e As EventArgs)
        hdnStudentID.Value = "0"
        txtFullName.Text = ""
        txtEmail.Text = ""
        txtPhone.Text = ""
        txtAddress.Text = ""
        txtDOB.Text = ""
        btnSave.Text = "Save Student"
    End Sub

    Protected Sub gvStudents_PageIndexChanging(sender As Object, e As GridViewPageEventArgs)
        gvStudents.PageIndex = e.NewPageIndex
        BindGrid()
    End Sub

    Protected Sub gvStudents_RowCommand(sender As Object, e As GridViewCommandEventArgs)
        Dim id As Integer = Convert.ToInt32(e.CommandArgument)
        If e.CommandName = "EditStudent" Then
            Dim dt As DataTable = DBHelper.GetDataTable("SELECT * FROM Students WHERE StudentID = " & id)
            If dt.Rows.Count > 0 Then
                Dim row As DataRow = dt.Rows(0)
                hdnStudentID.Value = row("StudentID").ToString()
                txtFullName.Text = row("FullName").ToString()
                txtEmail.Text = row("Email").ToString()
                txtPhone.Text = row("Phone").ToString()
                txtAddress.Text = row("Address").ToString()
                txtDOB.Text = If(row("DOB") Is DBNull.Value, "", Convert.ToDateTime(row("DOB")).ToString("yyyy-MM-dd"))
                ddlGender.SelectedValue = row("GenderID").ToString()
                ddlCategory.SelectedValue = row("CategoryID").ToString()
                ddlCourse.SelectedValue = row("CourseID").ToString()
                ddlSemester.SelectedValue = row("SemesterID").ToString()
                ddlCity.SelectedValue = row("CityID").ToString()
                ddlState.SelectedValue = row("StateID").ToString()
                btnSave.Text = "Update Student"
            End If
        ElseIf e.CommandName = "DeleteStudent" Then
            DBHelper.ExecuteProcedure("sp_DeleteStudent", {New SqlParameter("@StudentID", id)})
            BindGrid()
        End If
    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs)
        Dim searchStr As String = txtSearch.Text.Trim()
        If Not String.IsNullOrEmpty(searchStr) Then
            gvStudents.DataSource = DBHelper.GetDataTable("SELECT s.*, g.GenderName, c.CourseName, d.DeptName, sem.SemName FROM Students s INNER JOIN Genders g ON s.GenderID = g.GenderID INNER JOIN Courses c ON s.CourseID = c.CourseID INNER JOIN Departments d ON c.DeptID = d.DeptID INNER JOIN Semesters sem ON s.SemesterID = sem.SemesterID WHERE s.FullName LIKE '%" & searchStr & "%'")
            gvStudents.DataBind()
        Else
            BindGrid()
        End If
    End Sub
End Class
