<%@ Page Title="Students" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Students.aspx.vb" Inherits="Students" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Student Management</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-white">
            <strong>Add / Edit Student</strong>
        </div>
        <div class="card-body">
            <asp:HiddenField ID="hdnStudentID" runat="server" Value="0" />
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Full Name</label>
                    <asp:TextBox ID="txtFullName" runat="server" CssClass="form-control" />
                    <asp:RequiredFieldValidator ID="rfvName" runat="server" ControlToValidate="txtFullName" ErrorMessage="Required" ForeColor="Red" ValidationGroup="vgStudent" />
                </div>
                <div class="col-md-4">
                    <label class="form-label">Email</label>
                    <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" />
                    <asp:RegularExpressionValidator ID="revEmail" runat="server" ControlToValidate="txtEmail" ErrorMessage="Invalid email" ForeColor="Red" ValidationExpression="\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" ValidationGroup="vgStudent" />
                </div>
                <div class="col-md-4">
                    <label class="form-label">Phone</label>
                    <asp:TextBox ID="txtPhone" runat="server" CssClass="form-control" />
                </div>
                <div class="col-md-3">
                    <label class="form-label">Gender</label>
                    <asp:DropDownList ID="ddlGender" runat="server" CssClass="form-select" DataTextField="GenderName" DataValueField="GenderID"></asp:DropDownList>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Category</label>
                    <asp:DropDownList ID="ddlCategory" runat="server" CssClass="form-select" DataTextField="CategoryName" DataValueField="CategoryID"></asp:DropDownList>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Course</label>
                    <asp:DropDownList ID="ddlCourse" runat="server" CssClass="form-select" DataTextField="CourseName" DataValueField="CourseID"></asp:DropDownList>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Semester</label>
                    <asp:DropDownList ID="ddlSemester" runat="server" CssClass="form-select" DataTextField="SemName" DataValueField="SemesterID"></asp:DropDownList>
                </div>
                <div class="col-md-3">
                    <label class="form-label">City</label>
                    <asp:DropDownList ID="ddlCity" runat="server" CssClass="form-select" DataTextField="CityName" DataValueField="CityID"></asp:DropDownList>
                </div>
                <div class="col-md-3">
                    <label class="form-label">State</label>
                    <asp:DropDownList ID="ddlState" runat="server" CssClass="form-select" DataTextField="StateName" DataValueField="StateID"></asp:DropDownList>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Date of Birth</label>
                    <asp:TextBox ID="txtDOB" runat="server" CssClass="form-control" TextMode="Date" />
                </div>
                <div class="col-12">
                    <label class="form-label">Address</label>
                    <asp:TextBox ID="txtAddress" runat="server" CssClass="form-control" TextMode="MultiLine" Rows="2" />
                </div>
                <div class="col-12">
                    <asp:Button ID="btnSave" runat="server" Text="Save Student" CssClass="btn btn-success px-4" ValidationGroup="vgStudent" OnClick="btnSave_Click" />
                    <asp:Button ID="btnClear" runat="server" Text="Clear" CssClass="btn btn-outline-secondary px-4 ms-2" CausesValidation="false" OnClick="btnClear_Click" />
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <strong>Student List</strong>
            <div class="input-group w-25">
                <asp:TextBox ID="txtSearch" runat="server" CssClass="form-control" placeholder="Search by name..."></asp:TextBox>
                <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="btn btn-primary" OnClick="btnSearch_Click" CausesValidation="false" />
            </div>
        </div>
        <div class="card-body">
            <asp:GridView ID="gvStudents" runat="server" CssClass="table table-hover table-bordered" AutoGenerateColumns="false" 
                AllowPaging="true" PageSize="10" OnPageIndexChanging="gvStudents_PageIndexChanging" 
                OnRowCommand="gvStudents_RowCommand" DataKeyNames="StudentID">
                <Columns>
                    <asp:BoundField DataField="StudentID" HeaderText="ID" />
                    <asp:BoundField DataField="FullName" HeaderText="Name" />
                    <asp:BoundField DataField="CourseName" HeaderText="Course" />
                    <asp:BoundField DataField="SemName" HeaderText="Semester" />
                    <asp:BoundField DataField="Email" HeaderText="Email" />
                    <asp:BoundField DataField="Phone" HeaderText="Phone" />
                    <asp:TemplateField HeaderText="Actions">
                        <ItemTemplate>
                            <asp:LinkButton ID="btnEdit" runat="server" CommandName="EditStudent" CommandArgument='<%# Eval("StudentID") %>' CssClass="btn btn-sm btn-info text-white">Edit</asp:LinkButton>
                            <asp:LinkButton ID="btnDelete" runat="server" CommandName="DeleteStudent" CommandArgument='<%# Eval("StudentID") %>' CssClass="btn btn-sm btn-danger" OnClientClick="return confirm('Delete this record?');">Delete</asp:LinkButton>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
                <PagerStyle CssClass="pagination justify-content-center" />
                <HeaderStyle CssClass="table-dark" />
            </asp:GridView>
        </div>
    </div>
</asp:Content>
