-- 1. DATABASE CREATION
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'StudentMgmtDB')
BEGIN
    CREATE DATABASE StudentMgmtDB;
END
GO

USE StudentMgmtDB;
GO

-- 2. LOOKUP TABLES
CREATE TABLE Departments (DeptID INT PRIMARY KEY IDENTITY(1,1), DeptName NVARCHAR(100) NOT NULL);
CREATE TABLE Courses (CourseID INT PRIMARY KEY IDENTITY(1,1), CourseName NVARCHAR(100) NOT NULL, DeptID INT FOREIGN KEY REFERENCES Departments(DeptID));
CREATE TABLE Genders (GenderID INT PRIMARY KEY IDENTITY(1,1), GenderName NVARCHAR(20) NOT NULL);
CREATE TABLE Cities (CityID INT PRIMARY KEY IDENTITY(1,1), CityName NVARCHAR(100) NOT NULL);
CREATE TABLE States (StateID INT PRIMARY KEY IDENTITY(1,1), StateName NVARCHAR(100) NOT NULL);
CREATE TABLE Semesters (SemesterID INT PRIMARY KEY IDENTITY(1,1), SemName NVARCHAR(20) NOT NULL);
CREATE TABLE AttendanceStatus (StatusID INT PRIMARY KEY IDENTITY(1,1), StatusName NVARCHAR(20) NOT NULL);
CREATE TABLE FeesStatus (FeesStatusID INT PRIMARY KEY IDENTITY(1,1), StatusName NVARCHAR(20) NOT NULL);
CREATE TABLE StudentCategory (CategoryID INT PRIMARY KEY IDENTITY(1,1), CategoryName NVARCHAR(50) NOT NULL);

-- 3. MAIN TABLES
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) UNIQUE NOT NULL,
    Password NVARCHAR(100) NOT NULL,
    FullName NVARCHAR(100),
    Role NVARCHAR(20) DEFAULT 'Admin'
);

CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1001,1),
    FullName NVARCHAR(100) NOT NULL,
    DOB DATE,
    GenderID INT FOREIGN KEY REFERENCES Genders(GenderID),
    CategoryID INT FOREIGN KEY REFERENCES StudentCategory(CategoryID),
    Email NVARCHAR(100),
    Phone NVARCHAR(20),
    Address NVARCHAR(MAX),
    CityID INT FOREIGN KEY REFERENCES Cities(CityID),
    StateID INT FOREIGN KEY REFERENCES States(StateID),
    CourseID INT FOREIGN KEY REFERENCES Courses(CourseID),
    SemesterID INT FOREIGN KEY REFERENCES Semesters(SemesterID),
    EnrollmentDate DATE DEFAULT GETDATE()
);

CREATE TABLE Attendance (
    AttendanceID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT FOREIGN KEY REFERENCES Students(StudentID),
    AttendanceDate DATE,
    StatusID INT FOREIGN KEY REFERENCES AttendanceStatus(StatusID)
);

CREATE TABLE Fees (
    FeeID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT FOREIGN KEY REFERENCES Students(StudentID),
    AmountPaid DECIMAL(18,2),
    PaymentDate DATE,
    FeesStatusID INT FOREIGN KEY REFERENCES FeesStatus(FeesStatusID)
);

CREATE TABLE Results (
    ResultID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT FOREIGN KEY REFERENCES Students(StudentID),
    SemesterID INT FOREIGN KEY REFERENCES Semesters(SemesterID),
    SubjectName NVARCHAR(100),
    MarksObtained INT,
    TotalMarks INT,
    Grade NVARCHAR(5)
);

-- 4. SEED DATA
INSERT INTO Departments (DeptName) VALUES ('Computer Science'), ('Mechanical'), ('Electronics'), ('Civil');
INSERT INTO Courses (CourseName, DeptID) VALUES ('B.Tech CSE', 1), ('M.Tech CSE', 1), ('B.E Mechanical', 2);
INSERT INTO Genders (GenderName) VALUES ('Male'), ('Female'), ('Other');
INSERT INTO StudentCategory (CategoryName) VALUES ('General'), ('OBC'), ('SC/ST');
INSERT INTO Cities (CityName) VALUES ('New York'), ('London'), ('Mumbai'), ('Tokyo');
INSERT INTO States (StateID, StateName) VALUES (1, 'NY'), (2, 'England'), (3, 'Maharashtra'), (4, 'Kanto');
INSERT INTO Semesters (SemName) VALUES ('Sem 1'), ('Sem 2'), ('Sem 3'), ('Sem 4');
INSERT INTO AttendanceStatus (StatusName) VALUES ('Present'), ('Absent'), ('Late');
INSERT INTO FeesStatus (StatusName) VALUES ('Paid'), ('Pending'), ('Partial');
INSERT INTO Users (Username, Password, FullName) VALUES ('admin', 'admin123', 'System Administrator');

-- 5. STORED PROCEDURES
GO
CREATE PROCEDURE sp_GetStudents
AS
BEGIN
    SELECT s.*, g.GenderName, c.CourseName, d.DeptName, sem.SemName 
    FROM Students s
    INNER JOIN Genders g ON s.GenderID = g.GenderID
    INNER JOIN Courses c ON s.CourseID = c.CourseID
    INNER JOIN Departments d ON c.DeptID = d.DeptID
    INNER JOIN Semesters sem ON s.SemesterID = sem.SemesterID
END
GO

CREATE PROCEDURE sp_UpsertStudent
    @StudentID INT = NULL,
    @FullName NVARCHAR(100),
    @DOB DATE,
    @GenderID INT,
    @CategoryID INT,
    @Email NVARCHAR(100),
    @Phone NVARCHAR(20),
    @Address NVARCHAR(MAX),
    @CityID INT,
    @StateID INT,
    @CourseID INT,
    @SemesterID INT
AS
BEGIN
    IF @StudentID IS NULL OR @StudentID = 0
    BEGIN
        INSERT INTO Students (FullName, DOB, GenderID, CategoryID, Email, Phone, Address, CityID, StateID, CourseID, SemesterID)
        VALUES (@FullName, @DOB, @GenderID, @CategoryID, @Email, @Phone, @Address, @CityID, @StateID, @CourseID, @SemesterID)
    END
    ELSE
    BEGIN
        UPDATE Students SET 
            FullName = @FullName, DOB = @DOB, GenderID = @GenderID, CategoryID = @CategoryID,
            Email = @Email, Phone = @Phone, Address = @Address, CityID = @CityID, 
            StateID = @StateID, CourseID = @CourseID, SemesterID = @SemesterID
        WHERE StudentID = @StudentID
    END
END
GO

CREATE PROCEDURE sp_DeleteStudent @StudentID INT
AS
BEGIN
    DELETE FROM Results WHERE StudentID = @StudentID;
    DELETE FROM Attendance WHERE StudentID = @StudentID;
    DELETE FROM Fees WHERE StudentID = @StudentID;
    DELETE FROM Students WHERE StudentID = @StudentID;
END
GO

CREATE PROCEDURE sp_GetDashboardStats
AS
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM Students) as TotalStudents,
        (SELECT COUNT(*) FROM Departments) as TotalDepts,
        (SELECT COUNT(*) FROM Courses) as TotalCourses,
        (SELECT SUM(AmountPaid) FROM Fees) as TotalFeesCollected
END
GO
