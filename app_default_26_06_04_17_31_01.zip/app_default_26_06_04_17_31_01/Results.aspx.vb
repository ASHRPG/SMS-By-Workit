Imports System.Data
Imports System.Data.SqlClient

Partial Class Results
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadLookups()
            BindGrid()
        End If
    End Sub

    Private Sub LoadLookups()
        ddlResStudent.DataSource = DBHelper.GetDataTable("SELECT StudentID, FullName FROM Students")
        ddlResStudent.DataBind()
    End Sub

    Private Sub BindGrid()
        gvResults.DataSource = DBHelper.GetDataTable("SELECT s.FullName as Student, r.SubjectName, r.MarksObtained, r.TotalMarks, r.Grade FROM Results r JOIN Students s ON r.StudentID = s.StudentID")
        gvResults.DataBind()
    End Sub

    Protected Sub btnAddResult_Click(sender As Object, e As EventArgs)
        Dim marks As Integer = Convert.ToInt32(txtMarks.Text)
        Dim total As Integer = Convert.ToInt32(txtTotal.Text)
        Dim grade As String = GetGrade(marks, total)

        Dim sql As String = "INSERT INTO Results (StudentID, SemesterID, SubjectName, MarksObtained, TotalMarks, Grade) VALUES (@sid, 1, @sub, @m, @t, @g)"
        DBHelper.ExecuteProcedure("sp_executesql", {
            New SqlParameter("@statement", sql),
            New SqlParameter("@sid", ddlResStudent.SelectedValue),
            New SqlParameter("@sub", txtSubject.Text),
            New SqlParameter("@m", marks),
            New SqlParameter("@t", total),
            New SqlParameter("@g", grade)
        })
        BindGrid()
    End Sub

    Private Function GetGrade(marks As Integer, total As Integer) As String
        Dim perc As Double = (marks / total) * 100
        If perc >= 90 Then Return "A+"
        If perc >= 80 Then Return "A"
        If perc >= 70 Then Return "B"
        If perc >= 60 Then Return "C"
        If perc >= 50 Then Return "D"
        Return "F"
    End Function
End Class
