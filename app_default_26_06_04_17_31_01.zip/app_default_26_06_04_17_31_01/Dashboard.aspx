<%@ Page Title="Dashboard" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Dashboard.aspx.vb" Inherits="Dashboard" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Dashboard Overview</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="row g-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white shadow-sm">
                <div class="card-body text-center">
                    <h6>Total Students</h6>
                    <h2><asp:Label ID="lblTotalStudents" runat="server">0</asp:Label></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white shadow-sm">
                <div class="card-body text-center">
                    <h6>Departments</h6>
                    <h2><asp:Label ID="lblTotalDepts" runat="server">0</asp:Label></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-dark shadow-sm">
                <div class="card-body text-center">
                    <h6>Active Courses</h6>
                    <h2><asp:Label ID="lblTotalCourses" runat="server">0</asp:Label></h2>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white shadow-sm">
                <div class="card-body text-center">
                    <h6>Fees Collected</h6>
                    <h2>$<asp:Label ID="lblTotalFees" runat="server">0</asp:Label></h2>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-5">
        <h4>Recent Activities</h4>
        <p class="text-muted">Quick links to common tasks:</p>
        <div class="list-group">
            <a href="Students.aspx" class="list-group-item list-group-item-action">Register New Student</a>
            <a href="Attendance.aspx" class="list-group-item list-group-item-action">Mark Attendance</a>
            <a href="Results.aspx" class="list-group-item list-group-item-action">Upload Results</a>
        </div>
    </div>
</asp:Content>
