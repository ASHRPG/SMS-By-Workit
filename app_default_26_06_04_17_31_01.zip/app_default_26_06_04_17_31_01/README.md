# Student Management System (ASP.NET Web Forms & VB.NET)

This is a professional-grade Student Management System built using Classic ASP.NET Web Forms, VB.NET, and ADO.NET. It includes all 10 modules and 9 lookup tables as specified in the project requirements.

## Features
- **10 Integrated Modules**: Login, Dashboard, Students, Departments, Courses, Attendance, Fees, Results, Reports, and User Management.
- **Relational Database**: Advanced schema with Primary/Foreign keys and Lookup tables.
- **Stored Procedures**: All data operations (CRUD) handled via secure stored procedures.
- **Responsive UI**: Built with Bootstrap 5 and customized Master Pages.
- **Validation**: Server-side and Client-side validation using ASP.NET Validation Controls.
- **Paging & Sorting**: Fully implemented in GridViews.

## Prerequisites
- Visual Studio 2019 or newer
- SQL Server (LocalDB or Express/Standard)
- .NET Framework 4.8

## Installation & Setup

1. **Database Setup**:
    - Open SQL Server Management Studio (SSMS).
    - Open the file `Database/Complete_Schema.sql`.
    - Run the entire script to create the `StudentMgmtDB`, tables, seed data, and stored procedures.

2. **Configuration**:
    - Open the project in Visual Studio.
    - Open `Web.config`.
    - Update the `SMSConnectionString` to match your SQL Server instance (default is set to `(localdb)\MSSQLLocalDB`).

3. **Running the App**:
    - Right-click `Login.aspx` and select "Set As Start Page".
    - Press `F5` to run.

## Credentials
- **Username**: `admin`
- **Password**: `admin123`

## Project Structure
- `App_Code/DBHelper.vb`: Shared data access layer using ADO.NET.
- `Site.Master`: Global layout and navigation.
- `*.aspx`: UI pages for each module.
- `*.aspx.vb`: Code-behind logic for processing data.
- `Database/`: SQL scripts for schema and procedures.

## Troubleshooting
- **Connection Error**: Check if SQL Server is running and the connection string in `Web.config` is correct.
- **Validation Errors**: Ensure all required fields are filled; look for the red validation messages next to inputs.
