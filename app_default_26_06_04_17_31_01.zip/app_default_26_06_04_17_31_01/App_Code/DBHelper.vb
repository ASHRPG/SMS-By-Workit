Imports System
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Public Class DBHelper
    ' This is the variable your methods should use
    Private Shared connString As String = ConfigurationManager.ConnectionStrings("SMSConnectionString").ConnectionString

    Public Shared Function GetDataTable(query As String, Optional params As SqlParameter() = Nothing) As DataTable
        Using conn As New SqlConnection(connString)
            Using cmd As New SqlCommand(query, conn)
                If params IsNot Nothing Then cmd.Parameters.AddRange(params)
                Using da As New SqlDataAdapter(cmd)
                    Dim dt As New DataTable()
                    da.Fill(dt)
                    Return dt
                End Using
            End Using
        End Using
    End Function

    Public Shared Function ExecuteProcedure(procName As String, params As SqlParameter()) As Integer
        Using conn As New SqlConnection(connString)
            Using cmd As New SqlCommand(procName, conn)
                cmd.CommandType = CommandType.StoredProcedure
                If params IsNot Nothing Then cmd.Parameters.AddRange(params)
                conn.Open()
                Return cmd.ExecuteNonQuery()
            End Using
        End Using
    End Function

    Public Shared Function GetDataTableFromProc(procName As String, Optional params As SqlParameter() = Nothing) As DataTable
        Using conn As New SqlConnection(connString)
            Using cmd As New SqlCommand(procName, conn)
                cmd.CommandType = CommandType.StoredProcedure
                If params IsNot Nothing Then cmd.Parameters.AddRange(params)
                Using da As New SqlDataAdapter(cmd)
                    Dim dt As New DataTable()
                    da.Fill(dt)
                    Return dt
                End Using
            End Using
        End Using
    End Function

    Public Shared Function ExecuteNonQuery(query As String, params As SqlParameter(), isStoredProcedure As Boolean) As Integer
        ' FIXED: Changed GetConnectionString() to connString
        Using conn As New SqlConnection(connString)
            Using cmd As New SqlCommand(query, conn)
                If isStoredProcedure Then
                    cmd.CommandType = CommandType.StoredProcedure
                Else
                    cmd.CommandType = CommandType.Text
                End If

                If params IsNot Nothing Then
                    ' Good practice to clear parameters before adding
                    cmd.Parameters.Clear()
                    cmd.Parameters.AddRange(params)
                End If

                conn.Open()
                Return cmd.ExecuteNonQuery()
            End Using
        End Using
    End Function
End Class