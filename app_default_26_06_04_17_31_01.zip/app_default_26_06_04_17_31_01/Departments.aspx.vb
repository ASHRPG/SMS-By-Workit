Imports System.Data.SqlClient

Partial Class Departments
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then BindGrid()
    End Sub

    Private Sub BindGrid()
        gvDepts.DataSource = DBHelper.GetDataTable("SELECT * FROM Departments")
        gvDepts.DataBind()
    End Sub

    Protected Sub btnAddDept_Click(sender As Object, e As EventArgs)
        If Not String.IsNullOrEmpty(txtDeptName.Text) Then
            DBHelper.ExecuteProcedure("sp_executesql", {
                New SqlParameter("@statement", "INSERT INTO Departments (DeptName) VALUES (@d)"),
                New SqlParameter("@d", txtDeptName.Text)
            })
            txtDeptName.Text = ""
            BindGrid()
        End If
    End Sub
End Class
