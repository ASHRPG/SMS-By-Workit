Imports System.Data
Imports System.Data.SqlClient

Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub btnLogin_Click(sender As Object, e As EventArgs)
        Dim dt As DataTable = DBHelper.GetDataTable("SELECT * FROM Users WHERE Username = @u AND Password = @p", {
            New SqlParameter("@u", txtUsername.Text.Trim()),
            New SqlParameter("@p", txtPassword.Text.Trim())
        })

        If dt.Rows.Count > 0 Then
            FormsAuthentication.RedirectFromLoginPage(txtUsername.Text, False)
        Else
            lblError.Text = "Invalid username or password"
        End If
    End Sub
End Class
