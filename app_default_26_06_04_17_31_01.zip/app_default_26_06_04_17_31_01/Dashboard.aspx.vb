Imports System.Data

Partial Class Dashboard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadStats()
        End If
    End Sub

    Private Sub LoadStats()
        Dim dt As DataTable = DBHelper.GetDataTableFromProc("sp_GetDashboardStats")
        If dt.Rows.Count > 0 Then
            Dim row As DataRow = dt.Rows(0)
            lblTotalStudents.Text = row("TotalStudents").ToString()
            lblTotalDepts.Text = row("TotalDepts").ToString()
            lblTotalCourses.Text = row("TotalCourses").ToString()
            lblTotalFees.Text = If(row("TotalFeesCollected") Is DBNull.Value, "0", row("TotalFeesCollected").ToString())
        End If
    End Sub
End Class
