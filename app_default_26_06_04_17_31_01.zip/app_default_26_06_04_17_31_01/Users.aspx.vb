Partial Class Users
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            gvUsers.DataSource = DBHelper.GetDataTable("SELECT UserID, Username, FullName, Role FROM Users")
            gvUsers.DataBind()
        End If
    End Sub
End Class
