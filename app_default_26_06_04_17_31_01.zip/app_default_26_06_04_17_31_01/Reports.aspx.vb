Imports System.Data

Partial Class Reports
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadReports()
        End If
    End Sub

    Private Sub LoadReports()
        gvEnrollmentRep.DataSource = DBHelper.GetDataTable("SELECT c.CourseName, COUNT(s.StudentID) as TotalStudents FROM Courses c LEFT JOIN Students s ON c.CourseID = s.CourseID GROUP BY c.CourseName")
        gvEnrollmentRep.DataBind()

        gvAttendanceRep.DataSource = DBHelper.GetDataTable("SELECT AttendanceDate, StatusName, COUNT(*) as Count FROM Attendance a JOIN AttendanceStatus s ON a.StatusID = s.StatusID GROUP BY AttendanceDate, StatusName")
        gvAttendanceRep.DataBind()
    End Sub
End Class
