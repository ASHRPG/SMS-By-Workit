<%@ Page Title="Reports" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Reports.aspx.vb" Inherits="Reports" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">System Reports</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white">Student Enrollment by Course</div>
                <div class="card-body">
                    <asp:GridView ID="gvEnrollmentRep" runat="server" CssClass="table table-sm" AutoGenerateColumns="true" />
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-dark text-white">Daily Attendance Summary</div>
                <div class="card-body">
                    <asp:GridView ID="gvAttendanceRep" runat="server" CssClass="table table-sm" AutoGenerateColumns="true" />
                </div>
            </div>
        </div>
    </div>
    <div class="text-end mt-4">
        <button type="button" class="btn btn-outline-secondary" onclick="window.print();">Print Page Report</button>
    </div>
</asp:Content>
