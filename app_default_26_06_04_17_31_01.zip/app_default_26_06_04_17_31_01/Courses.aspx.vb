Imports System.Data.SqlClient

Partial Class Courses
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            If Not IsPostBack Then
                ddlDept.DataSource = DBHelper.GetDataTable("SELECT * FROM Departments")
                ddlDept.DataBind()
                BindGrid()
            End If
        Catch ex As Exception
            lblError.Text = ex.Message
        End Try
    End Sub

    Private Sub BindGrid()
        gvCourses.DataSource = DBHelper.GetDataTable("SELECT c.CourseID, c.CourseName, d.DeptName FROM Courses c JOIN Departments d ON c.DeptID = d.DeptID")
        gvCourses.DataBind()
    End Sub

    Protected Sub btnAddCourse_Click(sender As Object, e As EventArgs)
        Try
            ' Ensure the parameter names match exactly what is in your SQL Stored Procedure
            Dim params As SqlParameter() = {
            New SqlParameter("@CourseName", txtCourseName.Text),
            New SqlParameter("@DeptID", ddlDept.SelectedValue)
        }

            ' Call the helper - replace "sp_AddCourse" with your actual procedure name
            DBHelper.ExecuteNonQuery("sp_AddCourse", params, True)
            lblMessage.ForeColor = System.Drawing.Color.Green
            lblMessage.Text = "Course added successfully!"
            BindGrid()
        Catch ex As Exception
            lblMessage.ForeColor = System.Drawing.Color.Red
            lblMessage.Text = "Error: " & ex.Message
        End Try
    End Sub
End Class
