<%@ Page Title="Fees" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Fees.aspx.vb" Inherits="Fees" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Fees Management</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="row">
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">Record Payment</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Student</label>
                        <asp:DropDownList ID="ddlStudent" runat="server" CssClass="form-select" DataTextField="FullName" DataValueField="StudentID"></asp:DropDownList>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Amount</label>
                        <asp:TextBox ID="txtAmount" runat="server" CssClass="form-control" TextMode="Number"></asp:TextBox>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <asp:DropDownList ID="ddlFeeStatus" runat="server" CssClass="form-select" DataTextField="StatusName" DataValueField="FeesStatusID"></asp:DropDownList>
                    </div>
                    <asp:Button ID="btnPay" runat="server" Text="Process Payment" CssClass="btn btn-success w-100" OnClick="btnPay_Click" />
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-white">Payment History</div>
                <div class="card-body">
                    <asp:GridView ID="gvFees" runat="server" CssClass="table table-hover" AutoGenerateColumns="false">
                        <Columns>
                            <asp:BoundField DataField="FullName" HeaderText="Student" />
                            <asp:BoundField DataField="AmountPaid" HeaderText="Amount" DataFormatString="{0:C}" />
                            <asp:BoundField DataField="PaymentDate" HeaderText="Date" DataFormatString="{0:d}" />
                            <asp:BoundField DataField="StatusName" HeaderText="Status" />
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
        </div>
    </div>
</asp:Content>
