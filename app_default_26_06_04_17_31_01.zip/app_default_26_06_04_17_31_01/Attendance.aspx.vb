Imports System.Data
Imports System.Data.SqlClient

Partial Class Attendance
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            txtAttDate.Text = DateTime.Now.ToString("yyyy-MM-dd")
            BindGrid()
        End If
    End Sub

    Private Sub BindGrid()
        Dim dtStudents As DataTable = DBHelper.GetDataTable("SELECT StudentID, FullName FROM Students")
        gvAttendance.DataSource = dtStudents
        gvAttendance.DataBind()

        Dim dtStatus As DataTable = DBHelper.GetDataTable("SELECT StatusID, StatusName FROM AttendanceStatus")

        For Each row As GridViewRow In gvAttendance.Rows
            Dim rbl As RadioButtonList = DirectCast(row.FindControl("rblStatus"), RadioButtonList)
            rbl.DataSource = dtStatus
            rbl.DataBind()

            ' Pre-select "Present" (StatusID 1)
            If rbl.Items.Count > 0 Then rbl.SelectedIndex = 0
        Next
    End Sub

    Protected Sub btnSaveAttendance_Click(sender As Object, e As EventArgs)
        Dim attDate As String = txtAttDate.Text
        For Each row As GridViewRow In gvAttendance.Rows
            Dim studentID As Integer = Convert.ToInt32(gvAttendance.DataKeys(row.RowIndex).Value)
            Dim rbl As RadioButtonList = DirectCast(row.FindControl("rblStatus"), RadioButtonList)
            Dim statusID As Integer = Convert.ToInt32(rbl.SelectedValue)

            ' Simple Insert (In production, use a SP with MERGE or check existence)
            DBHelper.ExecuteProcedure("sp_executesql", {
                New SqlParameter("@statement", "DELETE FROM Attendance WHERE StudentID=@sid AND AttendanceDate=@dt; INSERT INTO Attendance(StudentID, AttendanceDate, StatusID) VALUES(@sid, @dt, @st)"),
                New SqlParameter("@sid", studentID),
                New SqlParameter("@dt", attDate),
                New SqlParameter("@st", statusID)
            })
        Next
        ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Attendance saved successfully');", True)
    End Sub

    Protected Sub txtAttDate_TextChanged(sender As Object, e As EventArgs)
        ' Logic to load existing attendance for that date if needed
    End Sub
End Class
