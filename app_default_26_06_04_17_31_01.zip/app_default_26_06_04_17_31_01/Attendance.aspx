<%@ Page Title="Attendance" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Attendance.aspx.vb" Inherits="Attendance" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Attendance Tracking</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="card shadow-sm p-3 mb-4">
        <div class="row align-items-end">
            <div class="col-md-4">
                <label class="form-label">Select Date</label>
                <asp:TextBox ID="txtAttDate" runat="server" CssClass="form-control" TextMode="Date" AutoPostBack="true" OnTextChanged="txtAttDate_TextChanged"></asp:TextBox>
            </div>
            <div class="col-md-4">
                <asp:Button ID="btnSaveAttendance" runat="server" Text="Save Attendance" CssClass="btn btn-primary" OnClick="btnSaveAttendance_Click" />
            </div>
        </div>
    </div>

    <asp:GridView ID="gvAttendance" runat="server" CssClass="table table-bordered table-striped" AutoGenerateColumns="false" DataKeyNames="StudentID">
        <Columns>
            <asp:BoundField DataField="StudentID" HeaderText="ID" />
            <asp:BoundField DataField="FullName" HeaderText="Student Name" />
            <asp:TemplateField HeaderText="Status">
                <ItemTemplate>
                    <asp:RadioButtonList ID="rblStatus" runat="server" RepeatDirection="Horizontal" DataTextField="StatusName" DataValueField="StatusID">
                    </asp:RadioButtonList>
                </ItemTemplate>
            </asp:TemplateField>
        </Columns>
        <HeaderStyle CssClass="table-dark" />
    </asp:GridView>
</asp:Content>
