<%@ Page Title="Courses" Language="VB" MasterPageFile="~/Site.Master" AutoEventWireup="false" CodeFile="Courses.aspx.vb" Inherits="Courses" %>

<asp:Content ID="Content1" ContentPlaceHolderID="PageTitle" runat="server">Courses</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <div class="card shadow-sm w-75 mb-4">
        <div class="card-body row">
            <div class="mt-3">
                <asp:Label ID="lblError" runat="server"></asp:Label>
                <asp:Label ID="lblMessage" runat="server" EnableViewState="false"></asp:Label>
            </div>
        <div class="col-md-5">
                <asp:TextBox ID="txtCourseName" runat="server" CssClass="form-control" placeholder="Course Name"></asp:TextBox>
            </div>
            <div class="col-md-4">
                <asp:DropDownList ID="ddlDept" runat="server" CssClass="form-select" DataTextField="DeptName" DataValueField="DeptID"></asp:DropDownList>
            </div>
            <div class="col-md-3">
                <asp:Button ID="btnAddCourse" runat="server" Text="Add Course" CssClass="btn btn-primary w-100" OnClick="btnAddCourse_Click" />
            </div>
        </div>
    </div>
    <asp:GridView ID="gvCourses" runat="server" CssClass="table table-bordered w-75" AutoGenerateColumns="true"></asp:GridView>
</asp:Content>
